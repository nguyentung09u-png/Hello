package admin.tt;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

public class MainActivity extends Activity {

    private static final String BASE_URL = "https://login-4e2ba-default-rtdb.firebaseio.com/";
    private static final String ADMIN_TOKEN = "admin-xyz-2026";

    private EditText edtUser, edtMinutes;
    private LinearLayout listContainer;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 40, 40, 40);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("ADMIN PANEL");
        tvTitle.setTextSize(24);
        root.addView(tvTitle);

        edtUser = new EditText(this);
        edtUser.setHint("Tên user (vd: admin)");
        edtUser.setText("admin");
        root.addView(edtUser);

        edtMinutes = new EditText(this);
        edtMinutes.setHint("Số phút (vd: 10)");
        edtMinutes.setText("10");
        edtMinutes.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        root.addView(edtMinutes);

        Button btnCreate = new Button(this);
        btnCreate.setText("TẠO KEY");
        root.addView(btnCreate);

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(listContainer);

        setContentView(root);

        // Sửa Lambda thành Anonymous Class
        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String user = edtUser.getText().toString().trim();
                String minStr = edtMinutes.getText().toString().trim();
                
                if (user.isEmpty() || minStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Vui lòng nhập đủ thông tin", Toast.LENGTH_SHORT).show();
                    return;
                }

                final int minutes = Integer.parseInt(minStr);
                if (minutes <= 0) {
                    Toast.makeText(MainActivity.this, "Số phút không hợp lệ", Toast.LENGTH_SHORT).show();
                    return;
                }

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        createKey(user, minutes);
                    }
                }).start();
            }
        });
    }

    private void createKey(String user, int minutes) {
        try {
            String key = UUID.randomUUID().toString().replace("-", "").substring(0, 16);
            long createdAt = System.currentTimeMillis();
            long expiresAt = createdAt + (minutes * 60_000L);

            String json = String.format(
                "{\"user\":\"%s\",\"createdAt\":%d,\"expiresAt\":%d,\"adminToken\":\"%s\"}",
                user, createdAt, expiresAt, ADMIN_TOKEN
            );

            URL url = new URL(BASE_URL + "keys/" + key + ".json");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");

            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes("UTF-8"));
            os.close();

            final int code = conn.getResponseCode();
            conn.disconnect();

            final String finalKey = key;
            final String finalUser = user;
            final int finalMinutes = minutes;

            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (code == 200) {
                        showKeyDialog(finalKey, finalUser, finalMinutes);
                        addKeyToList(finalKey, finalUser, finalMinutes);
                    } else {
                        Toast.makeText(MainActivity.this, "Lỗi Rules Firebase: " + code, Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } catch (Exception e) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, "Lỗi mạng", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void showKeyDialog(final String key, String user, int minutes) {
        new AlertDialog.Builder(this)
            .setTitle("Key mới — " + user + " (" + minutes + " phút)")
            .setMessage(key)
            .setPositiveButton("COPY", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("Key", key);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(MainActivity.this, "Đã copy!", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("OK", null)
            .show();
    }

    private void addKeyToList(final String key, String user, int minutes) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 10, 0, 10);

        TextView tv = new TextView(this);
        tv.setText(user + " • " + minutes + "p\n" + key);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(tv);

        Button btnCopy = new Button(this);
        btnCopy.setText("COPY");
        btnCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("Key", key));
                Toast.makeText(MainActivity.this, "Đã copy!", Toast.LENGTH_SHORT).show();
            }
        });
        row.addView(btnCopy);

        Button btnDelete = new Button(this);
        btnDelete.setText("XÓA");
        
        final LinearLayout finalRow = row; // cần final cho Java 7
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        deleteKey(key, finalRow);
                    }
                }).start();
            }
        });
        row.addView(btnDelete);

        listContainer.addView(row);
    }

    private void deleteKey(String key, final View rowToRemove) {
        try {
            URL url = new URL(BASE_URL + "keys/" + key + ".json");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");
            
            final int code = conn.getResponseCode();
            conn.disconnect();

            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (code == 200) {
                        listContainer.removeView(rowToRemove);
                        Toast.makeText(MainActivity.this, "Đã xóa key", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Lỗi xóa key", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } catch (Exception e) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, "Lỗi mạng", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}