package login.v1;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Login extends Activity {

    private static final String BASE_URL = "https://login-4e2ba-default-rtdb.firebaseio.com/";
    private WebView webView;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1.html + bridge tên "Android"
        webView = WebViewLoader.load(this, "1.html", new Bridge(), "Android");
    }

    // ================== JS BRIDGE ==================
    public class Bridge {

        /** HTML gọi lúc load trang để điền sẵn key đã lưu */
        @JavascriptInterface
        public String getSavedKey() {
            return getSharedPreferences("app", Context.MODE_PRIVATE)
                    .getString("saved_key", "");
        }

        /** HTML gọi khi bấm Login. Java tự check Firebase. */
        @JavascriptInterface
        public void login(final String key) {
            if (key == null || key.trim().isEmpty()) {
                ui.post(new Runnable() {
                    public void run() { callJs("onLoginFail", "Vui lòng nhập key"); }
                });
                return;
            }
            final String k = key.trim();
            new Thread(new Runnable() {
                public void run() { checkKey(k); }
            }).start();
        }
    }
    // ===============================================

    private void checkKey(final String key) {
        try {
            URL url = new URL(BASE_URL + "keys/" + key + ".json");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            final int code = conn.getResponseCode();

            if (code == 200) {
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();
                conn.disconnect();

                // Firebase trả "null" nếu key không tồn tại
                if (sb.toString().equals("null")) {
                    callJsOnUi("onLoginFail", "Phiên không hợp lệ");
                    return;
                }

                // Lưu key để lần sau tự điền
                getSharedPreferences("app", Context.MODE_PRIVATE)
                        .edit().putString("saved_key", key).apply();

                // Báo HTML hiện trạng thái OK rồi chuyển Activity
                callJsOnUi("onLoginSuccess", key);
                ui.postDelayed(new Runnable() {
                    public void run() {
                        Intent it = new Intent(Login.this, MainActivity.class);
                        it.putExtra("key", key);
                        startActivity(it);
                        finish();
                    }
                }, 350); // chờ hiệu ứng "✔ Thành công"
            } else {
                conn.disconnect();
                callJsOnUi("onLoginFail", "Phiên không hợp lệ hoặc đã hết hạn");
            }
        } catch (Exception e) {
            callJsOnUi("onLoginFail", "Không kết nối Firebase");
        }
    }

    /** Gọi hàm JS trên UI thread */
    private void callJsOnUi(final String fn, final String arg) {
        ui.post(new Runnable() {
            public void run() { callJs(fn, arg); }
        });
    }

    private void callJs(String fn, String arg) {
        if (webView == null) return;
        String safe = arg == null ? "" : arg.replace("\\", "\\\\").replace("'", "\\'");
        webView.loadUrl("javascript:" + fn + "('" + safe + "')");
    }
}