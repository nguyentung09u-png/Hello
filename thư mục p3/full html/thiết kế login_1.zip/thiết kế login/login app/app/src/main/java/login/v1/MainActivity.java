package login.v1;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    private static final String BASE_URL = "https://login-4e2ba-default-rtdb.firebaseio.com/";
    private static final int TIMEOUT_MS = 10000;   // 10s cho mọi HTTP call

    private volatile boolean verified = false;
    private volatile boolean killed = false;                 // chống kill 2 lần
    private volatile String currentKey;
    private WebView webView;

    private final Handler watchdog = new Handler(Looper.getMainLooper());
    private Runnable watchdogTask;

    private volatile String user = "";
    private volatile long expiresAt = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        currentKey = getIntent().getStringExtra("key");
        if (currentKey == null || currentKey.isEmpty()) {
            Toast.makeText(this, "Thiếu key đăng nhập", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Load 2.html + bridge tên "Android"
        webView = WebViewLoader.load(this, "2.html", new Bridge(), "Android");

        // Verify + lấy info user/expiresAt ở background
        new Thread(new Runnable() {
            @Override
            public void run() {
                final boolean ok = fetchAndVerify(currentKey);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || killed) return;
                        if (ok) {
                            verified = true;
                            callJs("onSessionReady",
                                    user + "|" + expiresAt + "|" + currentKey);
                            startWatchdog();
                        } else {
                            callJs("onSessionExpired", "");
                            killAppDelayed(600);
                        }
                    }
                });
            }
        }, "verify-initial").start();
    }

    // ================== JS BRIDGE ==================
    public class Bridge {

        @JavascriptInterface
        public String getKey() { return currentKey == null ? "" : currentKey; }

        @JavascriptInterface
        public String getUser() { return user; }

        @JavascriptInterface
        public long getExpiresAt() { return expiresAt; }

        @JavascriptInterface
        public void logout() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    getSharedPreferences("app", MODE_PRIVATE)
                            .edit().remove("saved_key").apply();
                    verified = false;
                    killAppDelayed(150);
                }
            });
        }
    }
    // ===============================================

    private boolean fetchAndVerify(String key) {
        HttpURLConnection conn = null;
        BufferedReader reader = null;
        try {
            URL url = new URL(BASE_URL + "keys/" + key + ".json");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(TIMEOUT_MS);
            conn.setReadTimeout(TIMEOUT_MS);
            conn.setUseCaches(false);

            int code = conn.getResponseCode();
            if (code != 200) return false;

            reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);

            String json = sb.toString();
            if (json == null || json.equals("null") || json.length() < 2) return false;

            // Parse an toàn bằng JSONObject
            JSONObject obj = new JSONObject(json);
            user      = obj.optString("user", "");
            expiresAt = obj.optLong("expiresAt", 0L);

            if (expiresAt > 0 && System.currentTimeMillis() > expiresAt) {
                return false;   // hết hạn
            }
            return true;

        } catch (Exception e) {
            return false;
        } finally {
            try { if (reader != null) reader.close(); } catch (Exception ignored) {}
            if (conn != null) conn.disconnect();
        }
    }

    private void startWatchdog() {
        watchdogTask = new Runnable() {
            @Override
            public void run() {
                if (!verified || killed || isFinishing()) return;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final boolean ok = checkKeySilently(currentKey);
                        if (killed || isFinishing()) return;

                        if (ok) {
                            watchdog.postDelayed(watchdogTask, 60000);
                        } else {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (killed || isFinishing()) return;
                                    verified = false;
                                    callJs("onSessionExpired", "");
                                    killAppDelayed(600);
                                }
                            });
                        }
                    }
                }, "watchdog-check").start();
            }
        };
        watchdog.postDelayed(watchdogTask, 60000);
    }

    private boolean checkKeySilently(String key) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(BASE_URL + "keys/" + key + ".json");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(TIMEOUT_MS);
            conn.setReadTimeout(TIMEOUT_MS);
            conn.setUseCaches(false);
            int code = conn.getResponseCode();
            return code == 200;
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /** Gọi hàm JS — luôn trên UI thread, có guard */
    private void callJs(final String fn, final String arg) {
        if (isFinishing() || killed) return;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (killed || isFinishing() || webView == null) return;
                try {
                    String safe = arg == null ? ""
                            : arg.replace("\\", "\\\\").replace("'", "\\'");
                    webView.loadUrl("javascript:" + fn + "('" + safe + "')");
                } catch (Exception ignored) { }
            }
        });
    }

    /** Dừng watchdog, đóng app — chống gọi 2 lần */
    private void killAppDelayed(long delayMs) {
        if (killed) return;
        killed = true;
        try { watchdog.removeCallbacksAndMessages(null); } catch (Exception ignored) {}

        watchdog.postDelayed(new Runnable() {
            @Override
            public void run() {
                destroyWebViewSafely();
                finishAffinity();
            }
        }, delayMs);
    }

    /** Hủy WebView an toàn, tránh lỗi gắn kết View hoặc leak */
    private void destroyWebViewSafely() {
        if (webView != null) {
            try {
                if (webView.getParent() instanceof ViewGroup) {
                    ((ViewGroup) webView.getParent()).removeView(webView);
                }
                webView.stopLoading();
                webView.destroy();
            } catch (Exception ignored) {}
            webView = null;
        }
    }

    @Override
    protected void onDestroy() {
        killed = true;
        try { watchdog.removeCallbacksAndMessages(null); } catch (Exception ignored) {}
        destroyWebViewSafely();
        super.onDestroy();
    }
}
