package login.v1;

import android.app.Activity;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class WebViewLoader {

    // Giữ hàm cũ để không phá code khác
    public static WebView load(Activity activity, String fileName) {
        return load(activity, fileName, null, null);
    }

    // Hàm mới: có gắn JS bridge
    public static WebView load(Activity activity, String fileName,
                               Object jsBridge, String bridgeName) {
        WebView webView = new WebView(activity);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);

        // Phải add trước loadUrl thì JS mới gọi được
        if (jsBridge != null && bridgeName != null) {
            webView.addJavascriptInterface(jsBridge, bridgeName);
        }

        activity.setContentView(webView);
        webView.loadUrl("file:///android_asset/" + fileName);
        return webView;
    }
}